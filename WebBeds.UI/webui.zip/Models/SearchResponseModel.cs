﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebBeds.UI.Models
{
    public class SearchResponseModel
    {
        public string BoardType { get; set; }
        public string HotelName { get; set; }
        public string RateType { get; set; }
        public double BasePrice { get; set; }
        public double ActualPrice { get; set; }
    }
}

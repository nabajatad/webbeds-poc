﻿using Microsoft.AspNetCore.Mvc;
using WebBeds.UI.Models;

namespace WebBeds.UI.Controllers
{
    public class HotelsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Index(SearchRequestModel request)
        {
            return View();
        }
    }
}
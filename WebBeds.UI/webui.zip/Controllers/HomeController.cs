﻿namespace WebBeds.UI.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Configuration;
    using System;
    using WebBeds.UI.Models;

    public class HomeController : Controller
    {
        //ILogger logger;
        //IHotelService service;
        private readonly IConfigurationSection _appSettings;
        //private IWebBedsRepository _webBedsRepository;
        private readonly IConfiguration _config;

        public HomeController(IConfiguration config)
        {
            _config = config;
            _appSettings= _config.GetSection("AppSettings");
            //_webBedsRepository = new WebBedsRepository(_appSettings["WebBedsAPI_URL"]);
            //service = svc;
            //logger = log;
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index([FromBody]SearchRequestModel request)
        {
            try
            {
                var authCode = _appSettings["WebBedsAPI_AuthCode"];
                var apiMethodName = _appSettings["WebBedsAPI_FindBargain_MethodName"];
                //ViewData["ResultSet"] = _webBedsRepository.GetHotels(apiMethodName, request.DestinationId, request.Nights, authCode);
                //service.GetHotels();
                return View();
            }
            catch (Exception ex)
            {
                //logger.WriteLog(ex.Message);

            }
            return View();
        }
    }
}
